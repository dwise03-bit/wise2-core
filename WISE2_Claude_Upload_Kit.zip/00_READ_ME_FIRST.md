# WISE² MASTER IDENTITY — CLAUDE UPLOAD HANDOFF

PRIMARY VISUAL REFERENCE
Use `04_Master_Landing_Page_16x9.png` as the current landing-page design target.

MASTER ECOSYSTEM IDENTITY
Use `03_Master_Identity_Poster.png` for the broader WISE² ecosystem visual language.

SOURCE PHOTOGRAPHY
- `01_Daniel_Wise_Source.png`
- `02_Darrin_Wise_Source.png`

Preserve the source photography. Do not regenerate or alter facial identity.

BRAND ARCHITECTURE
WISE² Business OS = parent platform / command center.
PIFF CITY = equal Powered Business; purple/culture identity.
WISE SHINE = equal Powered Business; black/chrome/gold premium detailing identity.

LEADERSHIP
Daniel Wise — Founder & System Architect.
Darrin Wise — Operations & Growth Leader.

CORE ENDORSEMENT
POWERED BY WISE² BUSINESS OS

CORE MESSAGE
WISE² BUILDS THE SYSTEM.
PIFF CITY BUILDS THE CULTURE.
WISE SHINE BUILDS THE SHINE.
TOGETHER WE BUILD LEGACY.

IMPLEMENTATION RULE
Adapt the CURRENT WISE² application. Do not rebuild blindly or replace working functionality.
The visual references are design direction, not single raster backgrounds.
Translate them into responsive HTML/CSS/components, navigation, cards, CTAs, and dashboard UI.

Start with a repository audit before modifying production code.
